 
you can use this icon as systray icon. Copy "systray_icon.png" file to your config yarock directory /home/<name>/.config/.yarock/systray_icon.png